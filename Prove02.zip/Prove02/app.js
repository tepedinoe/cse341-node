function loadXMLDoc(p) {
    req=new XMLHttpRequest();
    req.onreadystatechange=function() {
        if (req.readyState==4 && req.status==200) {
            document.getElementById("div1").innerHTML=req.responseText;}
        } // end of onreadstatechange function
        req.open("GET",p,true);
        req.send();
        check("performance");
       // myFunction();
} // end of loadXMLDoc(

